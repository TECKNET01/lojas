// ===== CONFIGURAÇÃO =====
const API_URL = 'http://localhost:5000/api';

// ===== ELEMENTOS =====
const toast = document.getElementById('toast');
let currentTab = 'produtos';

// ===== TOAST =====
function showToast(msg, isError = false) {
    toast.textContent = msg;
    toast.style.borderColor = isError ? '#e74c3c' : 'var(--acai-secondary)';
    toast.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => toast.classList.remove('show'), 3000);
}

// ===== TABS =====
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const tab = this.dataset.tab;
        currentTab = tab;
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.getElementById(`tab-${tab}`).classList.add('active');
        
        // Carregar dados da tab
        if (tab === 'produtos') carregarProdutos();
        else if (tab === 'complementos') carregarComplementos();
        else if (tab === 'coberturas') carregarCoberturas();
        else if (tab === 'avisos') carregarAvisos();
        else if (tab === 'pedidos') carregarPedidos();
    });
});

// ===== LOGOUT =====
document.getElementById('logoutBtn').addEventListener('click', async function(e) {
    e.preventDefault();
    try {
        await fetch(`${API_URL}/logout`, { method: 'POST', credentials: 'include' });
        window.location.href = '/';
    } catch (error) {
        showToast('❌ Erro ao sair', true);
    }
});

// ===== TEMA =====
const themeToggle = document.getElementById('themeToggle');
const htmlElement = document.documentElement;
const savedTheme = localStorage.getItem('acai-theme');
if (savedTheme) htmlElement.setAttribute('data-theme', savedTheme);

themeToggle.addEventListener('click', function() {
    const current = htmlElement.getAttribute('data-theme');
    const newTheme = current === 'dark' ? 'light' : 'dark';
    htmlElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('acai-theme', newTheme);
});

// ===== FUNÇÕES CRUD =====

// --- PRODUTOS ---
async function carregarProdutos() {
    try {
        const response = await fetch(`${API_URL}/produtos`);
        const data = await response.json();
        const tbody = document.getElementById('tabelaProdutos');
        tbody.innerHTML = '';
        data.forEach(p => {
            const status = p.em_falta ? 
                '<span class="status-badge status-falta">Em Falta</span>' : 
                '<span class="status-badge status-ok">Disponível</span>';
            tbody.innerHTML += `
                <tr>
                    <td>${p.id}</td>
                    <td>${p.nome}</td>
                    <td>R$ ${p.preco.toFixed(2)}</td>
                    <td>${p.categoria}</td>
                    <td>${status}</td>
                    <td>
                        <button class="btn btn-primary btn-xs" onclick="editarProduto(${p.id})"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-danger btn-xs" onclick="deletarProduto(${p.id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        showToast('❌ Erro ao carregar produtos', true);
    }
}

function editarProduto(id) {
    fetch(`${API_URL}/produtos/${id}`)
        .then(res => res.json())
        .then(produto => {
            document.getElementById('produtoId').value = produto.id;
            document.getElementById('prodNome').value = produto.nome;
            document.getElementById('prodPreco').value = produto.preco;
            document.getElementById('prodPrecoAntigo').value = produto.precoAntigo || '';
            document.getElementById('prodParcela').value = produto.parcela || '';
            document.getElementById('prodIcone').value = produto.icone;
            document.getElementById('prodTag').value = produto.tag || '';
            document.getElementById('prodCategoria').value = produto.categoria;
            document.getElementById('prodDestaque').value = produto.destaque ? 1 : 0;
            document.getElementById('prodEmFalta').value = produto.em_falta ? 1 : 0;
            document.getElementById('formProdutoTitle').innerHTML = '<i class="fas fa-edit"></i> Editar Produto';
            document.getElementById('formProduto').style.display = 'block';
            document.getElementById('formProduto').scrollIntoView({ behavior: 'smooth' });
        })
        .catch(() => showToast('❌ Erro ao carregar produto', true));
}

async function deletarProduto(id) {
    if (!confirm('Tem certeza que deseja deletar este produto?')) return;
    try {
        const response = await fetch(`${API_URL}/produtos/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showToast('✅ Produto deletado com sucesso!');
            carregarProdutos();
        } else {
            showToast('❌ Erro ao deletar produto', true);
        }
    } catch (error) {
        showToast('❌ Erro ao deletar produto', true);
    }
}

document.getElementById('btnNovoProduto').addEventListener('click', function() {
    document.getElementById('produtoId').value = '';
    document.getElementById('produtoForm').reset();
    document.getElementById('formProdutoTitle').innerHTML = '<i class="fas fa-plus"></i> Novo Produto';
    document.getElementById('formProduto').style.display = 'block';
    document.getElementById('formProduto').scrollIntoView({ behavior: 'smooth' });
});

document.getElementById('btnCancelarProduto').addEventListener('click', function() {
    document.getElementById('formProduto').style.display = 'none';
});

document.getElementById('produtoForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const id = document.getElementById('produtoId').value;
    const dados = {
        nome: document.getElementById('prodNome').value,
        preco: parseFloat(document.getElementById('prodPreco').value),
        precoAntigo: parseFloat(document.getElementById('prodPrecoAntigo').value) || null,
        parcela: document.getElementById('prodParcela').value,
        icone: document.getElementById('prodIcone').value || 'fa-bowl-food',
        tag: document.getElementById('prodTag').value,
        categoria: document.getElementById('prodCategoria').value,
        destaque: parseInt(document.getElementById('prodDestaque').value),
        em_falta: parseInt(document.getElementById('prodEmFalta').value)
    };

    try {
        const url = id ? `${API_URL}/produtos/${id}` : `${API_URL}/produtos`;
        const method = id ? 'PUT' : 'POST';
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(dados)
        });
        const result = await response.json();
        if (response.ok) {
            showToast(`✅ ${id ? 'Atualizado' : 'Criado'} com sucesso!`);
            document.getElementById('formProduto').style.display = 'none';
            carregarProdutos();
        } else {
            showToast(`❌ ${result.erro || 'Erro ao salvar'}`, true);
        }
    } catch (error) {
        showToast('❌ Erro ao salvar', true);
    }
});

// --- COMPLEMENTOS ---
async function carregarComplementos() {
    try {
        const response = await fetch(`${API_URL}/complementos`);
        const data = await response.json();
        const tbody = document.getElementById('tabelaComplementos');
        tbody.innerHTML = '';
        data.forEach(c => {
            const status = c.em_falta ? 
                '<span class="status-badge status-falta">Em Falta</span>' : 
                '<span class="status-badge status-ok">Disponível</span>';
            tbody.innerHTML += `
                <tr>
                    <td>${c.id}</td>
                    <td>${c.nome}</td>
                    <td>R$ ${c.preco.toFixed(2)}</td>
                    <td>${status}</td>
                    <td>
                        <button class="btn btn-primary btn-xs" onclick="editarComplemento(${c.id})"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-danger btn-xs" onclick="deletarComplemento(${c.id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        showToast('❌ Erro ao carregar complementos', true);
    }
}

function editarComplemento(id) {
    fetch(`${API_URL}/complementos/${id}`)
        .then(res => res.json())
        .then(c => {
            document.getElementById('complementoId').value = c.id;
            document.getElementById('compNome').value = c.nome;
            document.getElementById('compPreco').value = c.preco;
            document.getElementById('compIcone').value = c.icone || 'fa-seedling';
            document.getElementById('compEmFalta').value = c.em_falta ? 1 : 0;
            document.getElementById('formComplementoTitle').innerHTML = '<i class="fas fa-edit"></i> Editar Complemento';
            document.getElementById('formComplemento').style.display = 'block';
            document.getElementById('formComplemento').scrollIntoView({ behavior: 'smooth' });
        });
}

async function deletarComplemento(id) {
    if (!confirm('Tem certeza que deseja deletar este complemento?')) return;
    try {
        const response = await fetch(`${API_URL}/complementos/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showToast('✅ Complemento deletado com sucesso!');
            carregarComplementos();
        } else {
            showToast('❌ Erro ao deletar complemento', true);
        }
    } catch (error) {
        showToast('❌ Erro ao deletar complemento', true);
    }
}

document.getElementById('btnNovoComplemento').addEventListener('click', function() {
    document.getElementById('complementoId').value = '';
    document.getElementById('complementoForm').reset();
    document.getElementById('formComplementoTitle').innerHTML = '<i class="fas fa-plus"></i> Novo Complemento';
    document.getElementById('formComplemento').style.display = 'block';
});

document.getElementById('btnCancelarComplemento').addEventListener('click', function() {
    document.getElementById('formComplemento').style.display = 'none';
});

document.getElementById('complementoForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const id = document.getElementById('complementoId').value;
    const dados = {
        nome: document.getElementById('compNome').value,
        preco: parseFloat(document.getElementById('compPreco').value),
        icone: document.getElementById('compIcone').value || 'fa-seedling',
        em_falta: parseInt(document.getElementById('compEmFalta').value)
    };

    try {
        const url = id ? `${API_URL}/complementos/${id}` : `${API_URL}/complementos`;
        const method = id ? 'PUT' : 'POST';
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(dados)
        });
        if (response.ok) {
            showToast(`✅ ${id ? 'Atualizado' : 'Criado'} com sucesso!`);
            document.getElementById('formComplemento').style.display = 'none';
            carregarComplementos();
        } else {
            showToast('❌ Erro ao salvar', true);
        }
    } catch (error) {
        showToast('❌ Erro ao salvar', true);
    }
});

// --- COBERTURAS ---
async function carregarCoberturas() {
    try {
        const response = await fetch(`${API_URL}/coberturas`);
        const data = await response.json();
        const tbody = document.getElementById('tabelaCoberturas');
        tbody.innerHTML = '';
        data.forEach(c => {
            const status = c.em_falta ? 
                '<span class="status-badge status-falta">Em Falta</span>' : 
                '<span class="status-badge status-ok">Disponível</span>';
            tbody.innerHTML += `
                <tr>
                    <td>${c.id}</td>
                    <td>${c.nome}</td>
                    <td>R$ ${c.preco.toFixed(2)}</td>
                    <td>${status}</td>
                    <td>
                        <button class="btn btn-primary btn-xs" onclick="editarCobertura(${c.id})"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-danger btn-xs" onclick="deletarCobertura(${c.id})"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        showToast('❌ Erro ao carregar coberturas', true);
    }
}

function editarCobertura(id) {
    fetch(`${API_URL}/coberturas/${id}`)
        .then(res => res.json())
        .then(c => {
            document.getElementById('coberturaId').value = c.id;
            document.getElementById('covNome').value = c.nome;
            document.getElementById('covPreco').value = c.preco;
            document.getElementById('covIcone').value = c.icone || 'fa-bottle-droplet';
            document.getElementById('covEmFalta').value = c.em_falta ? 1 : 0;
            document.getElementById('formCoberturaTitle').innerHTML = '<i class="fas fa-edit"></i> Editar Cobertura';
            document.getElementById('formCobertura').style.display = 'block';
        });
}

async function deletarCobertura(id) {
    if (!confirm('Tem certeza que deseja deletar esta cobertura?')) return;
    try {
        const response = await fetch(`${API_URL}/coberturas/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showToast('✅ Cobertura deletada com sucesso!');
            carregarCoberturas();
        } else {
            showToast('❌ Erro ao deletar cobertura', true);
        }
    } catch (error) {
        showToast('❌ Erro ao deletar cobertura', true);
    }
}

document.getElementById('btnNovaCobertura').addEventListener('click', function() {
    document.getElementById('coberturaId').value = '';
    document.getElementById('coberturaForm').reset();
    document.getElementById('formCoberturaTitle').innerHTML = '<i class="fas fa-plus"></i> Nova Cobertura';
    document.getElementById('formCobertura').style.display = 'block';
});

document.getElementById('btnCancelarCobertura').addEventListener('click', function() {
    document.getElementById('formCobertura').style.display = 'none';
});

document.getElementById('coberturaForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const id = document.getElementById('coberturaId').value;
    const dados = {
        nome: document.getElementById('covNome').value,
        preco: parseFloat(document.getElementById('covPreco').value),
        icone: document.getElementById('covIcone').value || 'fa-bottle-droplet',
        em_falta: parseInt(document.getElementById('covEmFalta').value)
    };

    try {
        const url = id ? `${API_URL}/coberturas/${id}` : `${API_URL}/coberturas`;
        const method = id ? 'PUT' : 'POST';
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(dados)
        });
        if (response.ok) {
            showToast(`✅ ${id ? 'Atualizada' : 'Criada'} com sucesso!`);
            document.getElementById('formCobertura').style.display = 'none';
            carregarCoberturas();
        } else {
            showToast('❌ Erro ao salvar', true);
        }
    } catch (error) {
        showToast('❌ Erro ao salvar', true);
    }
});

// --- AVISOS ---
async function carregarAvisos() {
    try {
        const response = await fetch(`${API_URL}/avisos/todos`, { credentials: 'include' });
        const data = await response.json();
        const container = document.getElementById('listaAvisos');
        container.innerHTML = '';
        if (data.length === 0) {
            container.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 1rem;">Nenhum aviso cadastrado</p>';
            return;
        }
        data.forEach(a => {
            const status = a.ativo ? '✅ Ativo' : '❌ Inativo';
            container.innerHTML += `
                <div class="aviso-item">
                    <div>
                        <div class="aviso-text">${a.mensagem}</div>
                        <div class="aviso-data">${new Date(a.data_criacao).toLocaleDateString()} · ${status}</div>
                    </div>
                    <div class="aviso-actions">
                        <button class="btn btn-primary btn-xs" onclick="editarAviso(${a.id})"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-danger btn-xs" onclick="deletarAviso(${a.id})"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
            `;
        });
    } catch (error) {
        showToast('❌ Erro ao carregar avisos', true);
    }
}

function editarAviso(id) {
    fetch(`${API_URL}/avisos/todos`, { credentials: 'include' })
        .then(res => res.json())
        .then(avisos => {
            const aviso = avisos.find(a => a.id === id);
            if (aviso) {
                document.getElementById('avisoId').value = aviso.id;
                document.getElementById('avisoMensagem').value = aviso.mensagem;
                document.getElementById('avisoAtivo').value = aviso.ativo ? 1 : 0;
                document.getElementById('formAvisoTitle').innerHTML = '<i class="fas fa-edit"></i> Editar Aviso';
                document.getElementById('formAviso').style.display = 'block';
            }
        });
}

async function deletarAviso(id) {
    if (!confirm('Tem certeza que deseja deletar este aviso?')) return;
    try {
        const response = await fetch(`${API_URL}/avisos/${id}`, { 
            method: 'DELETE',
            credentials: 'include'
        });
        if (response.ok) {
            showToast('✅ Aviso deletado com sucesso!');
            carregarAvisos();
        } else {
            showToast('❌ Erro ao deletar aviso', true);
        }
    } catch (error) {
        showToast('❌ Erro ao deletar aviso', true);
    }
}

document.getElementById('btnNovoAviso').addEventListener('click', function() {
    document.getElementById('avisoId').value = '';
    document.getElementById('avisoForm').reset();
    document.getElementById('formAvisoTitle').innerHTML = '<i class="fas fa-plus"></i> Novo Aviso';
    document.getElementById('formAviso').style.display = 'block';
});

document.getElementById('btnCancelarAviso').addEventListener('click', function() {
    document.getElementById('formAviso').style.display = 'none';
});

document.getElementById('avisoForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const id = document.getElementById('avisoId').value;
    const dados = {
        mensagem: document.getElementById('avisoMensagem').value,
        ativo: parseInt(document.getElementById('avisoAtivo').value)
    };

    try {
        const url = id ? `${API_URL}/avisos/${id}` : `${API_URL}/avisos`;
        const method = id ? 'PUT' : 'POST';
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(dados)
        });
        if (response.ok) {
            showToast(`✅ ${id ? 'Atualizado' : 'Criado'} com sucesso!`);
            document.getElementById('formAviso').style.display = 'none';
            carregarAvisos();
        } else {
            showToast('❌ Erro ao salvar', true);
        }
    } catch (error) {
        showToast('❌ Erro ao salvar', true);
    }
});

// ===== CARREGAR PEDIDOS (Admin) =====
async function carregarPedidos() {
    try {
        const response = await fetch(`${API_URL}/pedidos`, { credentials: 'include' });
        const data = await response.json();
        const tbody = document.getElementById('tabelaPedidos');
        document.getElementById('totalPedidos').textContent = `Total: ${data.length} pedidos`;
        tbody.innerHTML = '';
        if (data.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--text-muted);">Nenhum pedido encontrado</td></tr>`;
            return;
        }
        data.forEach(p => {
            // Verificar se foi cancelado pelo usuário (apenas para admin ver)
            const canceladoPorUsuario = p.observacao && p.observacao.includes('cancelado pelo usuário');
            const bloqueadoAdmin = canceladoPorUsuario && p.status === 'Cancelado';
            
            const statusColors = {
                'Recebido': 'status-ok',
                'Preparando': 'status-ok',
                'Saiu para entrega': 'status-ok',
                'Entregue': 'status-ok',
                'Cancelado': 'status-falta'
            };
            tbody.innerHTML += `
                <tr>
                    <td>#${p.id}</td>
                    <td>${p.usuario_nome}</td>
                    <td>R$ ${p.total.toFixed(2)}</td>
                    <td>
                        <span class="status-badge ${statusColors[p.status] || 'status-ok'}">${p.status}</span>
                        <!-- MOSTRAR APENAS PARA ADMIN -->
                        ${canceladoPorUsuario ? '<span style="font-size:0.6rem;color:#e74c3c;display:block;font-weight:600;">⚠️ Cancelado pelo usuário</span>' : ''}
                    </td>
                    <td>${new Date(p.data).toLocaleDateString()}</td>
                    <td>
                        ${bloqueadoAdmin ? `
                            <span style="color:#e74c3c;font-size:0.7rem;font-weight:600;">
                                <i class="fas fa-lock"></i> Bloqueado
                            </span>
                        ` : `
                            <select onchange="atualizarStatus(${p.id}, this.value)" style="padding:0.3rem;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-input);color:var(--text-primary);">
                                <option value="Recebido" ${p.status === 'Recebido' ? 'selected' : ''}>Recebido</option>
                                <option value="Preparando" ${p.status === 'Preparando' ? 'selected' : ''}>Preparando</option>
                                <option value="Saiu para entrega" ${p.status === 'Saiu para entrega' ? 'selected' : ''}>Saiu para entrega</option>
                                <option value="Entregue" ${p.status === 'Entregue' ? 'selected' : ''}>Entregue</option>
                                <option value="Cancelado" ${p.status === 'Cancelado' ? 'selected' : ''}>Cancelado</option>
                            </select>
                        `}
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        showToast('❌ Erro ao carregar pedidos', true);
    }
}

// ===== ATUALIZAR STATUS (Admin) =====
async function atualizarStatus(id, status) {
    try {
        const response = await fetch(`${API_URL}/pedidos/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ status })
        });
        const result = await response.json();
        
        if (response.ok) {
            showToast('✅ Status atualizado com sucesso!');
            carregarPedidos();
        } else {
            // Mostrar erro específico
            if (result.erro && result.erro.includes('cancelado pelo usuário')) {
                showToast('❌ Este pedido foi cancelado pelo usuário e não pode ser alterado.', true);
            } else {
                showToast(`❌ ${result.erro || 'Erro ao atualizar status'}`, true);
            }
        }
    } catch (error) {
        showToast('❌ Erro ao atualizar status', true);
    }
}

// ===== INICIALIZAR =====
carregarProdutos();
console.log('👑 Painel Administrativo carregado!');