// ===== ELEMENTOS =====
const sections = {
    1: document.getElementById('section1'),
    2: document.getElementById('section2'),
    3: document.getElementById('section3'),
    4: document.getElementById('section4')
};

const steps = {
    1: document.getElementById('step1'),
    2: document.getElementById('step2'),
    3: document.getElementById('step3'),
    4: document.getElementById('step4')
};

const lines = {
    1: document.getElementById('line1'),
    2: document.getElementById('line2'),
    3: document.getElementById('line3')
};

// ===== ESTADO =====
let selectedSize = null;
let selectedComplementos = [];
let selectedCoberturas = [];
let currentStep = 1;
const maxCoberturas = 2;

// ===== TOAST =====
function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => toast.classList.remove('show'), 2800);
}

// ===== NAVEGAÇÃO ENTRE SEÇÕES =====
function goToStep(step) {
    // Esconder todas as seções
    Object.values(sections).forEach(s => s.classList.remove('active'));
    // Mostrar a seção atual
    sections[step].classList.add('active');
    
    // Atualizar steps
    Object.values(steps).forEach(s => s.classList.remove('active', 'done'));
    
    for (let i = 1; i <= 4; i++) {
        if (i < step) {
            steps[i].classList.add('done');
        } else if (i === step) {
            steps[i].classList.add('active');
        }
    }
    
    // Atualizar linhas
    for (let i = 1; i <= 3; i++) {
        if (i < step) {
            lines[i].classList.add('done');
        } else {
            lines[i].classList.remove('done');
        }
    }
    
    currentStep = step;
    
    // Atualizar subtítulo de complementos
    if (step === 2 && selectedSize) {
        const maxComp = parseInt(selectedSize.dataset.maxComp);
        document.getElementById('compSubtitle').textContent = 
            `Selecione até ${maxComp} complementos (${selectedComplementos.length}/${maxComp} selecionados)`;
    }
    
    // Atualizar resumo se for step 4
    if (step === 4) {
        atualizarResumo();
    }
    
    // Scroll para o topo
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ===== SEÇÃO 1: TAMANHO =====
const sizeCards = document.querySelectorAll('.size-card');
const btnNext1 = document.getElementById('btnNext1');

sizeCards.forEach(card => {
    card.addEventListener('click', function() {
        sizeCards.forEach(c => c.classList.remove('selected'));
        this.classList.add('selected');
        selectedSize = this;
        btnNext1.disabled = false;
        showToast(`✅ ${this.querySelector('.size-name').textContent} selecionado!`);
    });
});

btnNext1.addEventListener('click', function() {
    if (selectedSize) {
        // Resetar seleções anteriores
        selectedComplementos = [];
        selectedCoberturas = [];
        document.querySelectorAll('.complemento-item').forEach(c => c.classList.remove('selected'));
        document.querySelectorAll('.cobertura-item').forEach(c => c.classList.remove('selected'));
        goToStep(2);
    }
});

// ===== SEÇÃO 2: COMPLEMENTOS =====
const complementosItems = document.querySelectorAll('.complemento-item');
const btnNext2 = document.getElementById('btnNext2');
const btnPrev2 = document.getElementById('btnPrev2');

complementosItems.forEach(item => {
    item.addEventListener('click', function() {
        const maxComp = parseInt(selectedSize.dataset.maxComp);
        
        if (this.classList.contains('selected')) {
            this.classList.remove('selected');
            selectedComplementos = selectedComplementos.filter(c => c !== this);
        } else {
            if (selectedComplementos.length >= maxComp) {
                showToast(`⚠️ Máximo de ${maxComp} complementos permitidos!`);
                return;
            }
            this.classList.add('selected');
            selectedComplementos.push(this);
        }
        
        // Atualizar subtítulo
        document.getElementById('compSubtitle').textContent = 
            `Selecione até ${maxComp} complementos (${selectedComplementos.length}/${maxComp} selecionados)`;
        
        btnNext2.disabled = selectedComplementos.length === 0;
    });
});

btnNext2.addEventListener('click', function() {
    if (selectedComplementos.length > 0) {
        goToStep(3);
    }
});

btnPrev2.addEventListener('click', function() {
    goToStep(1);
});

// ===== SEÇÃO 3: COBERTURAS =====
const coberturasItems = document.querySelectorAll('.cobertura-item');
const btnNext3 = document.getElementById('btnNext3');
const btnPrev3 = document.getElementById('btnPrev3');

coberturasItems.forEach(item => {
    item.addEventListener('click', function() {
        if (this.classList.contains('selected')) {
            this.classList.remove('selected');
            selectedCoberturas = selectedCoberturas.filter(c => c !== this);
        } else {
            if (selectedCoberturas.length >= maxCoberturas) {
                showToast(`⚠️ Máximo de ${maxCoberturas} coberturas permitidas!`);
                return;
            }
            this.classList.add('selected');
            selectedCoberturas.push(this);
        }
        
        btnNext3.disabled = selectedCoberturas.length === 0;
    });
});

btnNext3.addEventListener('click', function() {
    if (selectedCoberturas.length > 0) {
        goToStep(4);
    }
});

btnPrev3.addEventListener('click', function() {
    goToStep(2);
});

// ===== SEÇÃO 4: RESUMO =====
const btnPrev4 = document.getElementById('btnPrev4');
const btnAddCart = document.getElementById('btnAddCart');

function atualizarResumo() {
    // Tamanho
    const sizeName = selectedSize.querySelector('.size-name').textContent;
    const sizePrice = parseFloat(selectedSize.dataset.price);
    document.getElementById('resumoTamanho').textContent = `${sizeName} - R$ ${sizePrice.toFixed(2)}`;
    
    // Complementos
    if (selectedComplementos.length > 0) {
        const compNames = selectedComplementos.map(c => c.dataset.nome).join(', ');
        document.getElementById('resumoComplementos').textContent = compNames;
    } else {
        document.getElementById('resumoComplementos').textContent = 'Nenhum';
    }
    
    // Coberturas
    if (selectedCoberturas.length > 0) {
        const covNames = selectedCoberturas.map(c => c.dataset.nome).join(', ');
        document.getElementById('resumoCoberturas').textContent = covNames;
    } else {
        document.getElementById('resumoCoberturas').textContent = 'Nenhuma';
    }
    
    // Calcular total
    let subtotal = sizePrice;
    
    selectedComplementos.forEach(c => {
        subtotal += parseFloat(c.dataset.preco);
    });
    
    selectedCoberturas.forEach(c => {
        subtotal += parseFloat(c.dataset.preco);
    });
    
    document.getElementById('resumoSubtotal').textContent = `R$ ${subtotal.toFixed(2)}`;
    document.getElementById('resumoTotal').textContent = `R$ ${subtotal.toFixed(2)}`;
    
    btnAddCart.disabled = false;
}

btnPrev4.addEventListener('click', function() {
    goToStep(3);
});

// ===== ADICIONAR AO CARRINHO =====
btnAddCart.addEventListener('click', function() {
    // Coletar dados do pedido
    const tamanho = selectedSize.querySelector('.size-name').textContent;
    const precoBase = parseFloat(selectedSize.dataset.price);
    
    const complementos = selectedComplementos.map(c => ({
        nome: c.dataset.nome,
        preco: parseFloat(c.dataset.preco)
    }));
    
    const coberturas = selectedCoberturas.map(c => ({
        nome: c.dataset.nome,
        preco: parseFloat(c.dataset.preco)
    }));
    
    let total = precoBase;
    complementos.forEach(c => total += c.preco);
    coberturas.forEach(c => total += c.preco);
    
    // Criar objeto do pedido
    const pedido = {
        tamanho: tamanho,
        precoBase: precoBase,
        complementos: complementos,
        coberturas: coberturas,
        total: total,
        descricao: `${tamanho} com ${complementos.map(c => c.nome).join(', ')} e ${coberturas.map(c => c.nome).join(', ')}`
    };
    
    // Salvar no sessionStorage
    const pedidosAtuais = JSON.parse(sessionStorage.getItem('pedidoPersonalizado') || '[]');
    pedidosAtuais.push(pedido);
    sessionStorage.setItem('pedidoPersonalizado', JSON.stringify(pedidosAtuais));
    
    showToast(`✅ Açaí adicionado ao carrinho! Total: R$ ${total.toFixed(2)}`);
    
    // Redirecionar para a home após 1.5s
    setTimeout(() => {
        window.location.href = '/';
    }, 1500);
});

// ===== TEMA CLARO/ESCURO =====
const themeToggle = document.getElementById('themeToggle');
const htmlElement = document.documentElement;

const savedTheme = localStorage.getItem('acai-theme');
if (savedTheme) {
    htmlElement.setAttribute('data-theme', savedTheme);
} else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    htmlElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('acai-theme', 'dark');
}

if (themeToggle) {
    themeToggle.addEventListener('click', function(e) {
        e.preventDefault();
        const currentTheme = htmlElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        htmlElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('acai-theme', newTheme);
        showToast(newTheme === 'dark' ? '🌙 Modo escuro ativado' : '☀️ Modo claro ativado');
    });
}

// ===== INICIAR =====
console.log('🍌 Página de montar açaí carregada!');
// ===== ADICIONAR AO CARRINHO =====
btnAddCart.addEventListener('click', function() {
    // Coletar dados do pedido
    const tamanho = selectedSize.querySelector('.size-name').textContent;
    const precoBase = parseFloat(selectedSize.dataset.price);
    
    const complementos = selectedComplementos.map(c => ({
        nome: c.dataset.nome,
        preco: parseFloat(c.dataset.preco)
    }));
    
    const coberturas = selectedCoberturas.map(c => ({
        nome: c.dataset.nome,
        preco: parseFloat(c.dataset.preco)
    }));
    
    let total = precoBase;
    complementos.forEach(c => total += c.preco);
    coberturas.forEach(c => total += c.preco);
    
    // Criar nome do produto personalizado
    let nomeProduto = `Açaí ${tamanho}`;
    if (complementos.length > 0) {
        nomeProduto += ` com ${complementos.map(c => c.nome).join(', ')}`;
    }
    if (coberturas.length > 0) {
        nomeProduto += ` e ${coberturas.map(c => c.nome).join(', ')}`;
    }
    
    // Criar objeto do pedido (mesmo formato dos produtos normais)
    const pedido = {
        id: Date.now(), // ID único temporário
        nome: nomeProduto,
        preco: total,
        precoAntigo: null,
        parcela: 'À vista',
        icone: 'fa-bowl-food',
        tag: 'personalizado',
        categoria: 'personalizado',
        destaque: false,
        em_falta: false,
        // Dados adicionais para o pedido personalizado
        personalizado: true,
        tamanho: tamanho,
        complementos: complementos,
        coberturas: coberturas,
        detalhes: {
            tamanho: tamanho,
            complementos: complementos.map(c => c.nome).join(', '),
            coberturas: coberturas.map(c => c.nome).join(', ')
        }
    };
    
    // Salvar no localStorage para o carrinho da página principal
    const carrinhoAtual = JSON.parse(localStorage.getItem('carrinhoPersonalizado') || '[]');
    carrinhoAtual.push(pedido);
    localStorage.setItem('carrinhoPersonalizado', JSON.stringify(carrinhoAtual));
    
    showToast(`✅ Açaí personalizado adicionado ao carrinho! Total: R$ ${total.toFixed(2)}`);
    
    // Redirecionar para a home após 1.5s
    setTimeout(() => {
        window.location.href = '/';
    }, 1500);
});