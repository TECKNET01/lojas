// ===== CONFIGURAÇÃO DA API =====
const API_URL = 'http://localhost:5000/api';

// ===== ESTADO GLOBAL =====
let produtos = [];
let cart = [];
let cartCount = 0;
let currentCategory = 'all';
let usuarioLogado = null;
let isLoginMode = false;

// ===== ELEMENTOS =====
const grid = document.getElementById('productGrid');
const cartBadge = document.getElementById('cartCount');
const cartItems = document.getElementById('cartItems');
const cartTotal = document.getElementById('cartTotal');
const checkoutBtn = document.getElementById('checkoutBtn');
const cartSidebar = document.getElementById('cartSidebar');
const cartOverlay = document.getElementById('cartOverlay');
const cartClose = document.getElementById('cartClose');
const cartBtn = document.getElementById('cartBtn');

// Elementos de autenticação
const authOverlay = document.getElementById('authOverlay');
const authModal = document.getElementById('authModal');
const authClose = document.getElementById('authClose');
const authBtn = document.getElementById('authBtn');
const authTitle = document.getElementById('authTitle');
const authForm = document.getElementById('authForm');
const authSubmit = document.getElementById('authSubmit');
const authSubmitText = document.getElementById('authSubmitText');
const authSwitchLink = document.getElementById('authSwitchLink');
const authSwitchText = document.getElementById('authSwitchText');
const authError = document.getElementById('authError');
const authSuccess = document.getElementById('authSuccess');

// Campos do formulário
const authNome = document.getElementById('authNome');
const authEmail = document.getElementById('authEmail');
const authTelefone = document.getElementById('authTelefone');
const authEndereco = document.getElementById('authEndereco');
const authSenha = document.getElementById('authSenha');
const authConfirmSenha = document.getElementById('authConfirmSenha');

// Grupos de campos para mostrar/esconder
const authNomeGroup = document.getElementById('authNomeGroup');
const authEnderecoGroup = document.getElementById('authEnderecoGroup');
const confirmSenhaGroup = document.getElementById('confirmSenhaGroup');

// ===== ELEMENTOS ADMIN E PEDIDOS =====
const adminBtn = document.getElementById('adminBtn');
const pedidosBtn = document.getElementById('pedidosBtn');
const avisosContainer = document.getElementById('avisosContainer');

// ===== FUNÇÕES DE API =====

// Verificar sessão
async function verificarSessao() {
    try {
        const response = await fetch(`${API_URL}/sessao`, {
            credentials: 'include'
        });
        if (!response.ok) throw new Error('Erro ao verificar sessão');
        const data = await response.json();
        if (data.logado) {
            usuarioLogado = data.usuario;
            atualizarUIUsuario();
            // Verificar se é admin
            if (usuarioLogado.is_admin) {
                if (adminBtn) adminBtn.style.display = 'flex';
            }
        }
        return data;
    } catch (error) {
        console.error('Erro ao verificar sessão:', error);
        return { logado: false };
    }
}

// Cadastrar usuário
async function cadastrarUsuario(dados) {
    const response = await fetch(`${API_URL}/usuarios`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dados)
    });
    return await response.json();
}

// Login
async function loginUsuario(email, senha) {
    const response = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, senha })
    });
    return await response.json();
}

// Logout
async function logoutUsuario() {
    const response = await fetch(`${API_URL}/logout`, {
        method: 'POST',
        credentials: 'include'
    });
    return await response.json();
}

// Carregar produtos
async function carregarProdutos() {
    try {
        const response = await fetch(`${API_URL}/produtos`);
        if (!response.ok) throw new Error('Erro ao carregar produtos');
        produtos = await response.json();
        renderProducts(currentCategory);
    } catch (error) {
        console.error('Erro:', error);
        showToast('❌ Erro ao carregar produtos.');
    }
}

// Buscar produtos
async function buscarProdutos(termo) {
    try {
        const response = await fetch(`${API_URL}/buscar?q=${encodeURIComponent(termo)}`);
        if (!response.ok) throw new Error('Erro na busca');
        return await response.json();
    } catch (error) {
        console.error('Erro na busca:', error);
        return produtos.filter(p => 
            p.nome.toLowerCase().includes(termo.toLowerCase()) ||
            p.tag.toLowerCase().includes(termo.toLowerCase()) ||
            p.categoria.includes(termo.toLowerCase())
        );
    }
}

// Criar pedido
async function criarPedido(itens, total, endereco = '', observacao = '') {
    const response = await fetch(`${API_URL}/pedidos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
            itens: itens,
            total: total,
            endereco: endereco,
            observacao: observacao
        })
    });
    return await response.json();
}

// ===== FUNÇÕES DO CARRINHO =====
function updateCartBadge() {
    cartBadge.textContent = cartCount;
}

function updateCart() {
    cartItems.innerHTML = '';
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="cart-empty">
                <i class="fas fa-shopping-bag"></i>
                <p>Seu carrinho está vazio</p>
                <p style="font-size:0.85rem;margin-top:0.5rem;">Adicione seus açaís favoritos!</p>
            </div>
        `;
        checkoutBtn.disabled = true;
        cartTotal.textContent = 'R$ 0,00';
        return;
    }

    let total = 0;
    cart.forEach((item, index) => {
        total += item.preco * item.quantidade;
        const div = document.createElement('div');
        div.className = 'cart-item';
        
        // Badge para personalizados
        const badgePersonalizado = item.personalizado ? ' ✨' : '';
        
        div.innerHTML = `
            <div class="cart-item-icon"><i class="fas ${item.icone}"></i></div>
            <div class="cart-item-info">
                <h4>${item.nome}${badgePersonalizado}</h4>
                <div class="cart-item-price">R$ ${item.preco.toFixed(2).replace('.', ',')}</div>
                ${item.personalizado && item.detalhes ? `
                    <div style="font-size:0.65rem;color:var(--text-muted);">
                        ${item.detalhes.tamanho} · ${item.detalhes.complementos} · ${item.detalhes.coberturas}
                    </div>
                ` : ''}
            </div>
            <div class="cart-item-qty">
                <button onclick="window.decrementCart(${index})">-</button>
                <span>${item.quantidade}</span>
                <button onclick="window.incrementCart(${index})">+</button>
            </div>
            <button class="cart-item-remove" onclick="window.removeFromCart(${index})"><i class="fas fa-trash-alt"></i></button>
        `;
        cartItems.appendChild(div);
    });

    cartTotal.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
    checkoutBtn.disabled = false;
}

window.incrementCart = function(index) {
    cart[index].quantidade += 1;
    cartCount += 1;
    updateCartBadge();
    updateCart();
};

window.decrementCart = function(index) {
    if (cart[index].quantidade > 1) {
        cart[index].quantidade -= 1;
        cartCount -= 1;
    } else {
        cartCount -= 1;
        cart.splice(index, 1);
    }
    updateCartBadge();
    updateCart();
};

window.removeFromCart = function(index) {
    cartCount -= cart[index].quantidade;
    cart.splice(index, 1);
    updateCartBadge();
    updateCart();
};

function addToCart(produto) {
    const existing = cart.find(item => item.id === produto.id);
    if (existing) {
        existing.quantidade += 1;
    } else {
        cart.push({ ...produto, quantidade: 1 });
    }
    cartCount += 1;
    updateCartBadge();
    updateCart();
    showToast(`🧉 ${produto.nome} adicionado!`);
}

// ===== CARREGAR PEDIDOS PERSONALIZADOS DO LOCALSTORAGE =====
function carregarPedidosPersonalizados() {
    try {
        const pedidosSalvos = JSON.parse(localStorage.getItem('carrinhoPersonalizado') || '[]');
        if (pedidosSalvos.length > 0) {
            let adicionados = 0;
            pedidosSalvos.forEach(pedido => {
                // Verificar se o produto já existe no carrinho (pelo ID)
                const existe = cart.find(item => item.id === pedido.id);
                if (!existe) {
                    // Adicionar ao carrinho
                    cart.push({
                        ...pedido,
                        quantidade: 1
                    });
                    cartCount += 1;
                    adicionados += 1;
                }
            });
            // Limpar o localStorage após adicionar
            localStorage.removeItem('carrinhoPersonalizado');
            updateCartBadge();
            updateCart();
            if (adicionados > 0) {
                showToast(`🍌 ${adicionados} açaí(s) personalizado(s) adicionado(s) ao carrinho!`);
            }
        }
    } catch (error) {
        console.error('Erro ao carregar pedidos personalizados:', error);
    }
}

// ===== TOAST =====
function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => toast.classList.remove('show'), 2800);
}

// ===== ABRIR/FECHAR CARRINHO =====
function openCart() {
    cartSidebar.classList.add('active');
    cartOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeCart() {
    cartSidebar.classList.remove('active');
    cartOverlay.classList.remove('active');
    document.body.style.overflow = '';
}

cartBtn.addEventListener('click', function(e) {
    e.preventDefault();
    openCart();
});

cartClose.addEventListener('click', closeCart);
cartOverlay.addEventListener('click', closeCart);

// ===== FUNÇÕES DE AUTENTICAÇÃO =====

function atualizarUIUsuario() {
    if (usuarioLogado) {
        // Atualizar botão de usuário
        authBtn.innerHTML = `
            <i class="fas fa-user-check"></i>
            <span style="font-size:0.85rem;max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                ${usuarioLogado.nome.split(' ')[0]}
            </span>
        `;
        
        // Adicionar botão de logout
        let logoutBtn = authBtn.parentNode.querySelector('.btn-logout');
        if (!logoutBtn) {
            logoutBtn = document.createElement('button');
            logoutBtn.className = 'btn-logout';
            logoutBtn.innerHTML = '<i class="fas fa-sign-out-alt"></i>';
            logoutBtn.title = 'Sair';
            logoutBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                fazerLogout();
            });
            authBtn.parentNode.insertBefore(logoutBtn, authBtn.nextSibling);
        }
        
        // Mostrar botão de pedidos
        if (pedidosBtn) {
            pedidosBtn.style.display = 'flex';
        }
        
        // Mostrar botão admin se for admin
        if (usuarioLogado.is_admin && adminBtn) {
            adminBtn.style.display = 'flex';
        }
        
    } else {
        // Usuário deslogado
        authBtn.innerHTML = `<i class="fas fa-user"></i> <span id="authBtnText">Entrar</span>`;
        
        const logoutBtn = authBtn.parentNode.querySelector('.btn-logout');
        if (logoutBtn) logoutBtn.remove();
        
        if (pedidosBtn) {
            pedidosBtn.style.display = 'none';
        }
        
        if (adminBtn) {
            adminBtn.style.display = 'none';
        }
    }
}

function abrirModal(mode = 'login') {
    isLoginMode = mode === 'login';
    authOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Resetar formulário e mensagens
    authForm.reset();
    authError.style.display = 'none';
    authSuccess.style.display = 'none';
    authError.textContent = '';
    authSuccess.textContent = '';
    
    // Remover required de campos que não serão usados
    authNome.removeAttribute('required');
    authTelefone.removeAttribute('required');
    authEndereco.removeAttribute('required');
    authConfirmSenha.removeAttribute('required');
    
    if (isLoginMode) {
        // MODO LOGIN
        authTitle.innerHTML = '<i class="fas fa-sign-in-alt"></i> Login';
        authSubmitText.textContent = 'Entrar';
        authSubmit.innerHTML = '<i class="fas fa-sign-in-alt"></i> Entrar';
        authSwitchText.textContent = 'Não tem uma conta?';
        authSwitchLink.textContent = 'Cadastre-se';
        
        // Esconder campos de cadastro
        authNomeGroup.style.display = 'none';
        authEnderecoGroup.style.display = 'none';
        confirmSenhaGroup.style.display = 'none';
        
        // Campo telefone fica opcional no login
        authTelefone.removeAttribute('required');
        
        // Email e senha são obrigatórios
        authEmail.setAttribute('required', 'required');
        authSenha.setAttribute('required', 'required');
        
    } else {
        // MODO CADASTRO
        authTitle.innerHTML = '<i class="fas fa-user-plus"></i> Cadastro';
        authSubmitText.textContent = 'Cadastrar';
        authSubmit.innerHTML = '<i class="fas fa-user-plus"></i> Cadastrar';
        authSwitchText.textContent = 'Já tem uma conta?';
        authSwitchLink.textContent = 'Faça login';
        
        // Mostrar todos os campos
        authNomeGroup.style.display = 'block';
        authEnderecoGroup.style.display = 'block';
        confirmSenhaGroup.style.display = 'block';
        
        // Todos os campos são obrigatórios no cadastro
        authNome.setAttribute('required', 'required');
        authTelefone.setAttribute('required', 'required');
        authEndereco.setAttribute('required', 'required');
        authConfirmSenha.setAttribute('required', 'required');
        authEmail.setAttribute('required', 'required');
        authSenha.setAttribute('required', 'required');
    }
}

function fecharModal() {
    authOverlay.classList.remove('active');
    document.body.style.overflow = '';
}

// Eventos do modal
authClose.addEventListener('click', fecharModal);
authOverlay.addEventListener('click', function(e) {
    if (e.target === this) fecharModal();
});

authBtn.addEventListener('click', function(e) {
    e.preventDefault();
    if (usuarioLogado) {
        showToast(`👋 Olá, ${usuarioLogado.nome}!`);
    } else {
        abrirModal('login');
    }
});

authSwitchLink.addEventListener('click', function(e) {
    e.preventDefault();
    abrirModal(isLoginMode ? 'cadastro' : 'login');
});

// ===== SUBMETER FORMULÁRIO =====
authForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    authError.style.display = 'none';
    authSuccess.style.display = 'none';
    
    // Pegar valores apenas dos campos visíveis
    const nome = authNomeGroup.style.display !== 'none' ? authNome.value.trim() : '';
    const email = authEmail.value.trim().toLowerCase();
    const telefone = authTelefone.value.trim();
    const endereco = authEnderecoGroup.style.display !== 'none' ? authEndereco.value.trim() : '';
    const senha = authSenha.value;
    const confirmSenha = authConfirmSenha.value;

    try {
        if (isLoginMode) {
            // LOGIN
            if (!email || !senha) {
                authError.textContent = 'Preencha email e senha';
                authError.style.display = 'block';
                return;
            }
            
            const resultado = await loginUsuario(email, senha);
            
            if (resultado.erro) {
                authError.textContent = resultado.erro;
                authError.style.display = 'block';
                return;
            }
            
            usuarioLogado = resultado.usuario;
            atualizarUIUsuario();
            fecharModal();
            showToast(`✅ Bem-vindo(a) de volta, ${usuarioLogado.nome}!`);
            
            // Recarregar avisos após login
            carregarAvisos();
            
        } else {
            // CADASTRO
            if (!nome || !email || !telefone || !endereco || !senha) {
                authError.textContent = 'Preencha todos os campos';
                authError.style.display = 'block';
                return;
            }
            
            if (senha !== confirmSenha) {
                authError.textContent = 'As senhas não coincidem';
                authError.style.display = 'block';
                return;
            }
            
            if (senha.length < 6) {
                authError.textContent = 'A senha deve ter no mínimo 6 caracteres';
                authError.style.display = 'block';
                return;
            }
            
            const resultado = await cadastrarUsuario({
                nome, email, telefone, endereco, senha
            });
            
            if (resultado.erro) {
                authError.textContent = resultado.erro;
                authError.style.display = 'block';
                return;
            }
            
            authSuccess.textContent = '✅ Cadastro realizado com sucesso! Faça login para continuar.';
            authSuccess.style.display = 'block';
            
            // Mudar para login após 1.5s
            setTimeout(() => {
                abrirModal('login');
                authEmail.value = email;
            }, 1500);
        }
    } catch (error) {
        authError.textContent = 'Erro de conexão. Tente novamente.';
        authError.style.display = 'block';
        console.error('Erro:', error);
    }
});

// ===== LOGOUT =====
async function fazerLogout() {
    try {
        await logoutUsuario();
        usuarioLogado = null;
        atualizarUIUsuario();
        showToast('👋 Até logo!');
        // Recarregar avisos após logout
        carregarAvisos();
    } catch (error) {
        console.error('Erro ao fazer logout:', error);
    }
}

// ===== CARREGAR AVISOS =====
async function carregarAvisos() {
    if (!avisosContainer) return;
    
    try {
        const response = await fetch(`${API_URL}/avisos`);
        if (!response.ok) throw new Error('Erro ao carregar avisos');
        const avisos = await response.json();
        
        avisosContainer.innerHTML = '';
        
        if (avisos.length === 0) {
            avisosContainer.style.display = 'none';
            return;
        }
        
        avisosContainer.style.display = 'block';
        avisos.forEach(aviso => {
            const div = document.createElement('div');
            div.style.cssText = `
                background: var(--acai-secondary);
                color: white;
                padding: 0.8rem 1.5rem;
                border-radius: 12px;
                margin-bottom: 0.5rem;
                text-align: center;
                font-weight: 600;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
            `;
            div.innerHTML = `
                <i class="fas fa-bell"></i>
                <span>${aviso.mensagem}</span>
            `;
            avisosContainer.appendChild(div);
        });
    } catch (error) {
        console.error('Erro ao carregar avisos:', error);
        avisosContainer.style.display = 'none';
    }
}

// ===== RENDERIZAR PRODUTOS =====
function renderProducts(categoria = 'all') {
    grid.innerHTML = '';
    
    // Se for categoria 'personalizado', mostrar apenas produtos personalizados do carrinho
    let produtosParaMostrar = [];
    
    if (categoria === 'personalizado') {
        const personalizados = cart.filter(item => item.personalizado);
        if (personalizados.length === 0) {
            grid.innerHTML = `<p style="grid-column: 1/-1; text-align: center; padding: 2rem; color: var(--text-muted); font-weight: 500;">Nenhum açaí personalizado no carrinho.</p>`;
            return;
        }
        produtosParaMostrar = personalizados;
    } else {
        // Filtrar produtos normais
        const filtered = categoria === 'all' ? produtos : produtos.filter(p => p.categoria === categoria);
        produtosParaMostrar = filtered;
    }
    
    if (produtosParaMostrar.length === 0) {
        grid.innerHTML = `<p style="grid-column: 1/-1; text-align: center; padding: 2rem; color: var(--text-muted); font-weight: 500;">Nenhum açaí encontrado nesta categoria.</p>`;
        return;
    }

    produtosParaMostrar.forEach(p => {
        const card = document.createElement('div');
        card.className = 'product-card';
        
        // Badge de "Personalizado" ou "Em Falta"
        let badgeHtml = '';
        if (p.personalizado) {
            badgeHtml = `<span class="product-badge" style="background:#f39c12;color:white;">✨ Personalizado</span>`;
        } else if (p.em_falta) {
            badgeHtml = `<span class="product-badge" style="background:#e74c3c;color:white;">❌ Indisponível</span>`;
        } else if (p.destaque) {
            badgeHtml = `<span class="product-badge">🔥 Destaque</span>`;
        }
        
        // Mostrar detalhes adicionais para personalizados
        let detalhesHtml = '';
        if (p.personalizado && p.detalhes) {
            detalhesHtml = `
                <div style="font-size:0.7rem;color:var(--text-muted);margin:0.2rem 0;">
                    <small>${p.detalhes.tamanho} · ${p.detalhes.complementos} · ${p.detalhes.coberturas}</small>
                </div>
            `;
        }
        
        card.innerHTML = `
            ${badgeHtml}
            <div class="product-img"><i class="fas ${p.icone}"></i></div>
            <h3>${p.nome}</h3>
            ${detalhesHtml}
            <div>
                <span class="price">R$ ${p.preco.toFixed(2).replace('.', ',')}</span>
                ${p.precoAntigo ? `<span class="old-price">R$ ${p.precoAntigo.toFixed(2).replace('.', ',')}</span>` : ''}
            </div>
            <div class="installment">${p.parcela || 'À vista'}</div>
            ${p.tag ? `<span class="product-tag">${p.tag}</span>` : ''}
            <button class="btn-add" data-id="${p.id}" ${p.em_falta ? 'disabled style="opacity:0.4;cursor:not-allowed;"' : ''}>
                <i class="fas fa-plus"></i> ${p.em_falta ? 'Indisponível' : 'Adicionar'}
            </button>
        `;
        grid.appendChild(card);
    });

    document.querySelectorAll('.btn-add:not([disabled])').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const id = parseInt(this.dataset.id);
            // Buscar primeiro nos produtos normais, depois nos personalizados
            let produto = produtos.find(p => p.id === id);
            if (!produto) {
                produto = cart.find(p => p.id === id && p.personalizado);
            }
            if (produto && !produto.em_falta) {
                addToCart(produto);
                this.style.background = 'var(--acai-secondary)';
                this.style.color = 'white';
                setTimeout(() => {
                    this.style.background = '';
                    this.style.color = '';
                }, 300);
            }
        });
    });
}

// ===== CATEGORIAS =====
document.querySelectorAll('.categories a').forEach(cat => {
    cat.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelectorAll('.categories a').forEach(c => c.classList.remove('active-cat'));
        this.classList.add('active-cat');
        const categoria = this.dataset.cat;
        currentCategory = categoria;
        renderProducts(categoria);
        showToast(`Filtrando: ${this.textContent.trim()}`);
    });
});

// ===== EVENTOS PRINCIPAIS =====
document.getElementById('heroBtn')?.addEventListener('click', function() {
    window.location.href = '/montar-acai';
});

document.getElementById('heroSecondaryBtn')?.addEventListener('click', function() {
    showToast('🎁 Ofertas especiais te esperam!');
});

document.getElementById('promoBtn')?.addEventListener('click', function() {
    const combo = produtos.find(p => p.id === 7);
    if (combo && !combo.em_falta) {
        addToCart(combo);
    } else {
        showToast('⚠️ Este produto está temporariamente indisponível');
    }
});

document.getElementById('viewAllLink')?.addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelectorAll('.categories a').forEach(c => c.classList.remove('active-cat'));
    document.querySelector('.categories a[data-cat="all"]')?.classList.add('active-cat');
    currentCategory = 'all';
    renderProducts('all');
    showToast('🔄 Exibindo todos os açaís');
});

document.getElementById('logoHome')?.addEventListener('click', function() {
    document.querySelectorAll('.categories a').forEach(c => c.classList.remove('active-cat'));
    document.querySelector('.categories a[data-cat="all"]')?.classList.add('active-cat');
    currentCategory = 'all';
    renderProducts('all');
    showToast('🏠 Voltar ao início');
});

// ===== PESQUISA =====
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('keydown', async function(e) {
        if (e.key === 'Enter') {
            const term = this.value.trim();
            if (term) {
                const resultados = await buscarProdutos(term);
                if (resultados.length > 0) {
                    grid.innerHTML = '';
                    resultados.forEach(p => {
                        const card = document.createElement('div');
                        card.className = 'product-card';
                        
                        let faltaBadge = '';
                        if (p.em_falta) {
                            faltaBadge = `<span class="product-badge" style="background:#e74c3c;color:white;">❌ Indisponível</span>`;
                        }
                        const badgeHtml = p.destaque && !p.em_falta ? `<span class="product-badge">🔥 Destaque</span>` : faltaBadge;
                        
                        card.innerHTML = `
                            ${badgeHtml}
                            <div class="product-img"><i class="fas ${p.icone}"></i></div>
                            <h3>${p.nome} ${p.em_falta ? '🚫' : ''}</h3>
                            <div>
                                <span class="price">R$ ${p.preco.toFixed(2).replace('.', ',')}</span>
                                <span class="old-price">R$ ${p.precoAntigo.toFixed(2).replace('.', ',')}</span>
                            </div>
                            <div class="installment">${p.parcela} sem juros</div>
                            <span class="product-tag">${p.tag}</span>
                            <button class="btn-add" data-id="${p.id}" ${p.em_falta ? 'disabled style="opacity:0.4;cursor:not-allowed;"' : ''}>
                                <i class="fas fa-plus"></i> ${p.em_falta ? 'Indisponível' : 'Adicionar'}
                            </button>
                        `;
                        grid.appendChild(card);
                    });
                    document.querySelectorAll('.btn-add:not([disabled])').forEach(btn => {
                        btn.addEventListener('click', function(e) {
                            e.stopPropagation();
                            const id = parseInt(this.dataset.id);
                            const produto = produtos.find(p => p.id === id);
                            if (produto && !produto.em_falta) {
                                addToCart(produto);
                            }
                        });
                    });
                    showToast(`🔍 Encontrados ${resultados.length} resultados`);
                } else {
                    showToast('😕 Nenhum açaí encontrado para "' + term + '"');
                }
            } else {
                showToast('Digite algo para buscar');
            }
        }
    });
}

// ===== FAVORITOS =====
document.getElementById('favoritesBtn')?.addEventListener('click', function(e) {
    e.preventDefault();
    if (usuarioLogado) {
        showToast('❤️ Seus favoritos estão vazios');
    } else {
        showToast('🔒 Faça login para ver seus favoritos');
        abrirModal('login');
    }
});

// ===== TEMA CLARO/ESCURO =====
const themeToggle = document.getElementById('themeToggle');
const htmlElement = document.documentElement;

const savedTheme = localStorage.getItem('acai-theme');
if (savedTheme) {
    htmlElement.setAttribute('data-theme', savedTheme);
} else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    htmlElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('acai-theme', 'dark');
}

if (themeToggle) {
    themeToggle.addEventListener('click', function(e) {
        e.preventDefault();
        const currentTheme = htmlElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        htmlElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('acai-theme', newTheme);
        showToast(newTheme === 'dark' ? '🌙 Modo escuro ativado' : '☀️ Modo claro ativado');
    });
}

// ===== CHECKOUT =====
checkoutBtn.addEventListener('click', async function() {
    if (cart.length === 0) return;
    
    // Verificar se usuário está logado
    if (!usuarioLogado) {
        showToast('🔒 Faça login para finalizar o pedido');
        abrirModal('login');
        return;
    }

    try {
        const total = cart.reduce((sum, item) => sum + (item.preco * item.quantidade), 0);
        const itensParaEnviar = cart.map(item => ({
            id: item.id,
            nome: item.nome,
            preco: item.preco,
            quantidade: item.quantidade,
            personalizado: item.personalizado || false,
            detalhes: item.detalhes || null
        }));
        
        const resultado = await criarPedido(
            itensParaEnviar, 
            total, 
            usuarioLogado.endereco,
            ''
        );
        
        if (resultado.erro) {
            showToast(`❌ ${resultado.erro}`);
            return;
        }
        
        showToast(`✅ Pedido #${resultado.pedido.id} finalizado! Total: R$ ${total.toFixed(2).replace('.', ',')}`);
        
        cart = [];
        cartCount = 0;
        updateCartBadge();
        updateCart();
        closeCart();
    } catch (error) {
        showToast('❌ Erro ao finalizar pedido. Tente novamente.');
        console.error('Erro no checkout:', error);
    }
});

// ===== INICIALIZAR =====
async function init() {
    try {
        // Carregar avisos primeiro (público)
        await carregarAvisos();
        
        // Verificar sessão e admin
        await verificarSessao();
        
        // Carregar produtos
        await carregarProdutos();
        
        // Carregar pedidos personalizados do localStorage
        carregarPedidosPersonalizados();
        
        // Atualizar carrinho
        updateCartBadge();
        updateCart();
        
        console.log('🍌 Açaí do Verão · Front-end carregado com sucesso!');
    } catch (error) {
        console.error('Erro na inicialização:', error);
        // Tentar carregar mesmo com erro
        await carregarProdutos();
        carregarPedidosPersonalizados();
        updateCartBadge();
        updateCart();
    }
}

// Iniciar o site
init();