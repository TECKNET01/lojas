// ===== CONFIGURAÇÃO =====
const API_URL = 'http://localhost:5000/api';

// ===== ELEMENTOS =====
const pedidosContainer = document.getElementById('pedidosContainer');
const toast = document.getElementById('toast');
const userName = document.getElementById('userName');
const userBadge = document.getElementById('userBadge');

// ===== TOAST =====
function showToast(msg, isError = false) {
    toast.textContent = msg;
    toast.style.borderColor = isError ? '#e74c3c' : 'var(--acai-secondary)';
    toast.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => toast.classList.remove('show'), 3500);
}

// ===== VERIFICAR SESSÃO =====
async function verificarSessao() {
    try {
        const response = await fetch(`${API_URL}/sessao`, { credentials: 'include' });
        const data = await response.json();
        if (data.logado) {
            userName.textContent = data.usuario.nome.split(' ')[0];
            return data.usuario;
        } else {
            window.location.href = '/';
            return null;
        }
    } catch (error) {
        console.error('Erro ao verificar sessão:', error);
        window.location.href = '/';
        return null;
    }
}

// ===== LOGOUT =====
document.getElementById('logoutBtn').addEventListener('click', async function(e) {
    e.preventDefault();
    try {
        await fetch(`${API_URL}/logout`, { method: 'POST', credentials: 'include' });
        window.location.href = '/';
    } catch (error) {
        showToast('❌ Erro ao sair', true);
    }
});

// ===== FUNÇÕES AUXILIARES DE STATUS =====
function getStatusClass(status) {
    const map = {
        'Recebido': 'status-recebido',
        'Preparando': 'status-preparando',
        'Saiu para entrega': 'status-saiu',
        'Entregue': 'status-entregue',
        'Cancelado': 'status-cancelado'
    };
    return map[status] || 'status-recebido';
}

function getStatusLabel(status) {
    const map = {
        'Recebido': '📦 Recebido',
        'Preparando': '⏳ Preparando',
        'Saiu para entrega': '🚚 Saiu para entrega',
        'Entregue': '✅ Entregue',
        'Cancelado': '❌ Cancelado'
    };
    return map[status] || status;
}

// ===== CANCELAR PEDIDO =====
async function cancelarPedido(id) {
    if (!confirm('Tem certeza que deseja cancelar este pedido? Esta ação não pode ser desfeita.')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/pedidos/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ 
                status: 'Cancelado',
                observacao: 'Pedido cancelado pelo usuário!'
            })
        });

        const result = await response.json();

        if (response.ok) {
            showToast('✅ Pedido cancelado com sucesso!');
            setTimeout(() => carregarPedidos(), 500);
        } else {
            showToast(`❌ ${result.erro || 'Erro ao cancelar pedido'}`, true);
        }
    } catch (error) {
        console.error('Erro ao cancelar pedido:', error);
        showToast('❌ Erro ao cancelar pedido. Tente novamente.', true);
    }
}

// ===== CARREGAR PEDIDOS =====
async function carregarPedidos() {
    try {
        const response = await fetch(`${API_URL}/pedidos`, { credentials: 'include' });
        if (response.status === 401) {
            window.location.href = '/';
            return;
        }
        const pedidos = await response.json();
        
        if (pedidos.length === 0) {
            pedidosContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-shopping-bag"></i>
                    <h2>Nenhum pedido encontrado</h2>
                    <p>Você ainda não fez nenhum pedido. Que tal começar agora?</p>
                    <a href="/" class="btn-primary"><i class="fas fa-arrow-left"></i> Voltar para loja</a>
                </div>
            `;
            return;
        }

        let html = '<div class="pedidos-grid">';
        
        pedidos.forEach(pedido => {
            const statusClass = getStatusClass(pedido.status);
            const statusLabel = getStatusLabel(pedido.status);
            const podeCancelar = pedido.status !== 'Cancelado' && pedido.status !== 'Entregue';
            const data = new Date(pedido.data);
            const dataFormatada = data.toLocaleDateString('pt-BR', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });

            let itensHtml = '';
            pedido.itens.forEach(item => {
                itensHtml += `
                    <div class="item">
                        <span class="item-nome">${item.quantidade}x ${item.nome}</span>
                        <span class="item-preco">R$ ${(item.preco * item.quantidade).toFixed(2)}</span>
                    </div>
                `;
            });

            // REMOVIDO: A mensagem "Cancelado pelo usuário" NÃO aparece para o usuário
            html += `
                <div class="pedido-card">
                    <div class="pedido-header">
                        <div class="pedido-info">
                            <div class="info-item">
                                <span class="label">Pedido #</span>
                                <span class="value">${pedido.id}</span>
                            </div>
                            <div class="info-item">
                                <span class="label">Data</span>
                                <span class="value">${dataFormatada}</span>
                            </div>
                            <div class="info-item">
                                <span class="label">Total</span>
                                <span class="value">R$ ${pedido.total.toFixed(2)}</span>
                            </div>
                            <div class="info-item">
                                <span class="label">Entrega</span>
                                <span class="value">${pedido.endereco}</span>
                            </div>
                        </div>
                        <div class="pedido-status">
                            <span class="status-badge ${statusClass}">${statusLabel}</span>
                        </div>
                    </div>

                    <div class="pedido-itens">
                        ${itensHtml}
                    </div>

                    <div class="pedido-total">
                        <span>Total do pedido</span>
                        <span class="total-price">R$ ${pedido.total.toFixed(2)}</span>
                    </div>

                    <div class="pedido-actions">
                        ${podeCancelar ? `
                            <button class="btn-cancelar" onclick="cancelarPedido(${pedido.id})">
                                <i class="fas fa-times"></i> Cancelar Pedido
                            </button>
                        ` : `
                            <span class="btn-cancelado">
                                <i class="fas fa-check-circle"></i> ${pedido.status === 'Cancelado' ? 'Pedido cancelado' : 'Pedido finalizado'}
                            </span>
                        `}
                    </div>
                </div>
            `;
        });

        html += '</div>';
        pedidosContainer.innerHTML = html;

    } catch (error) {
        console.error('Erro ao carregar pedidos:', error);
        pedidosContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h2>Erro ao carregar pedidos</h2>
                <p>Não foi possível carregar seus pedidos. Tente novamente mais tarde.</p>
                <button class="btn-primary" onclick="location.reload()"><i class="fas fa-sync"></i> Recarregar</button>
            </div>
        `;
    }
}

// ===== TEMA CLARO/ESCURO =====
const themeToggle = document.getElementById('themeToggle');
const htmlElement = document.documentElement;

const savedTheme = localStorage.getItem('acai-theme');
if (savedTheme) {
    htmlElement.setAttribute('data-theme', savedTheme);
} else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    htmlElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('acai-theme', 'dark');
}

if (themeToggle) {
    themeToggle.addEventListener('click', function(e) {
        e.preventDefault();
        const currentTheme = htmlElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        htmlElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('acai-theme', newTheme);
        showToast(newTheme === 'dark' ? '🌙 Modo escuro ativado' : '☀️ Modo claro ativado');
    });
}

// ===== INICIALIZAR =====
async function init() {
    const usuario = await verificarSessao();
    if (usuario) {
        await carregarPedidos();
    }
}

init();
console.log('📋 Página de pedidos carregada!');