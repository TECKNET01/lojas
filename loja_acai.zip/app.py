from flask import Flask, jsonify, request, render_template, session, abort, redirect, url_for
from flask_cors import CORS
from datetime import datetime
import hashlib
import re
import json
from database import (
    get_db_connection, 
    init_database, 
    serializar_produto, 
    serializar_usuario,
    serializar_pedido,
    serializar_complemento,
    serializar_cobertura,
    serializar_aviso
)

app = Flask(__name__)
app.secret_key = 'acai-do-verao-secret-key-2026'
CORS(app, supports_credentials=True)

# Inicializar banco de dados
init_database()

# ===== FUNÇÕES AUXILIARES =====

def validar_email(email):
    padrao = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(padrao, email) is not None

def validar_telefone(telefone):
    telefone_limpo = re.sub(r'\D', '', telefone)
    return len(telefone_limpo) >= 10 and len(telefone_limpo) <= 11

def hash_senha(senha):
    return hashlib.sha256(senha.encode()).hexdigest()

def verificar_admin():
    """Verifica se o usuário atual é administrador"""
    if 'usuario_id' not in session:
        return False
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT is_admin FROM usuarios WHERE id = ?', (session['usuario_id'],))
    usuario = cursor.fetchone()
    conn.close()
    
    return usuario and usuario['is_admin'] == 1

# ===== PÁGINAS DE ERRO =====

@app.errorhandler(404)
def pagina_nao_encontrada(e):
    return render_template('404.html'), 404

@app.errorhandler(403)
def pagina_proibida(e):
    return render_template('403.html'), 403

# ===== ROTAS =====

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/montar-acai')
def montar_acai():
    return render_template('montar-acai.html')

@app.route('/admin')
def admin_panel():
    if not verificar_admin():
        abort(403)
    return render_template('admin.html')

@app.route('/meus-pedidos')
def meus_pedidos():
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
    return render_template('pedidos.html')

# ===== ROTAS DE USUÁRIO =====

@app.route('/api/usuarios', methods=['POST'])
def cadastrar_usuario():
    dados = request.json
    
    campos_obrigatorios = ['nome', 'email', 'telefone', 'endereco', 'senha']
    for campo in campos_obrigatorios:
        if campo not in dados or not dados[campo]:
            return jsonify({'erro': f'O campo {campo} é obrigatório'}), 400
    
    if not validar_email(dados['email']):
        return jsonify({'erro': 'Email inválido'}), 400
    
    if not validar_telefone(dados['telefone']):
        return jsonify({'erro': 'Telefone inválido'}), 400
    
    if len(dados['senha']) < 6:
        return jsonify({'erro': 'A senha deve ter no mínimo 6 caracteres'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT id FROM usuarios WHERE email = ?', (dados['email'].strip().lower(),))
    if cursor.fetchone():
        conn.close()
        return jsonify({'erro': 'Email já cadastrado'}), 400
    
    cursor.execute('''
        INSERT INTO usuarios (nome, email, telefone, endereco, senha, data_cadastro, is_admin)
        VALUES (?, ?, ?, ?, ?, ?, 0)
    ''', (
        dados['nome'].strip(),
        dados['email'].strip().lower(),
        dados['telefone'].strip(),
        dados['endereco'].strip(),
        hash_senha(dados['senha']),
        datetime.now().isoformat()
    ))
    
    conn.commit()
    usuario_id = cursor.lastrowid
    
    cursor.execute('SELECT * FROM usuarios WHERE id = ?', (usuario_id,))
    usuario = cursor.fetchone()
    conn.close()
    
    return jsonify({
        'mensagem': 'Usuário cadastrado com sucesso!',
        'usuario': serializar_usuario(usuario)
    }), 201

@app.route('/api/login', methods=['POST'])
def login_usuario():
    dados = request.json
    
    if not dados or not dados.get('email') or not dados.get('senha'):
        return jsonify({'erro': 'Email e senha são obrigatórios'}), 400
    
    email = dados['email'].strip().lower()
    senha_hash = hash_senha(dados['senha'])
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM usuarios WHERE email = ? AND senha = ?', (email, senha_hash))
    usuario = cursor.fetchone()
    conn.close()
    
    if not usuario:
        return jsonify({'erro': 'Email ou senha inválidos'}), 401
    
    session['usuario_id'] = usuario['id']
    session['usuario_nome'] = usuario['nome']
    session['is_admin'] = bool(usuario['is_admin'])
    
    return jsonify({
        'mensagem': 'Login realizado com sucesso!',
        'usuario': serializar_usuario(usuario)
    })

@app.route('/api/logout', methods=['POST'])
def logout_usuario():
    session.clear()
    return jsonify({'mensagem': 'Logout realizado com sucesso'})

@app.route('/api/sessao', methods=['GET'])
def verificar_sessao():
    if 'usuario_id' in session:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM usuarios WHERE id = ?', (session['usuario_id'],))
        usuario = cursor.fetchone()
        conn.close()
        
        if usuario:
            return jsonify({
                'logado': True,
                'usuario': serializar_usuario(usuario)
            })
    
    return jsonify({'logado': False})

@app.route('/api/usuarios/<int:id>', methods=['PUT'])
def atualizar_usuario(id):
    if 'usuario_id' not in session or session['usuario_id'] != id:
        return jsonify({'erro': 'Não autorizado'}), 401
    
    dados = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM usuarios WHERE id = ?', (id,))
    usuario = cursor.fetchone()
    if not usuario:
        conn.close()
        return jsonify({'erro': 'Usuário não encontrado'}), 404
    
    updates = []
    params = []
    
    if 'nome' in dados:
        updates.append('nome = ?')
        params.append(dados['nome'].strip())
    if 'telefone' in dados:
        if not validar_telefone(dados['telefone']):
            conn.close()
            return jsonify({'erro': 'Telefone inválido'}), 400
        updates.append('telefone = ?')
        params.append(dados['telefone'].strip())
    if 'endereco' in dados:
        updates.append('endereco = ?')
        params.append(dados['endereco'].strip())
    if 'senha' in dados and dados['senha']:
        if len(dados['senha']) < 6:
            conn.close()
            return jsonify({'erro': 'A senha deve ter no mínimo 6 caracteres'}), 400
        updates.append('senha = ?')
        params.append(hash_senha(dados['senha']))
    
    if updates:
        params.append(id)
        cursor.execute(f'UPDATE usuarios SET {", ".join(updates)} WHERE id = ?', params)
        conn.commit()
    
    cursor.execute('SELECT * FROM usuarios WHERE id = ?', (id,))
    usuario = cursor.fetchone()
    conn.close()
    
    return jsonify({
        'mensagem': 'Dados atualizados com sucesso!',
        'usuario': serializar_usuario(usuario)
    })

# ===== ROTAS DE PRODUTOS =====

@app.route('/api/produtos', methods=['GET'])
def listar_produtos():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM produtos ORDER BY destaque DESC, id')
    produtos = cursor.fetchall()
    conn.close()
    return jsonify([serializar_produto(p) for p in produtos])

@app.route('/api/produtos', methods=['POST'])
def criar_produto():
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    dados = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO produtos (nome, preco, preco_antigo, parcela, icone, tag, categoria, destaque, em_falta)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        dados['nome'],
        dados['preco'],
        dados.get('precoAntigo'),
        dados.get('parcela'),
        dados.get('icone', 'fa-bowl-food'),
        dados.get('tag', ''),
        dados.get('categoria', 'tradicional'),
        dados.get('destaque', 0),
        dados.get('em_falta', 0)
    ))
    
    conn.commit()
    produto_id = cursor.lastrowid
    cursor.execute('SELECT * FROM produtos WHERE id = ?', (produto_id,))
    produto = cursor.fetchone()
    conn.close()
    
    return jsonify({'mensagem': 'Produto criado com sucesso!', 'produto': serializar_produto(produto)}), 201

@app.route('/api/produtos/<int:id>', methods=['PUT'])
def atualizar_produto(id):
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    dados = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM produtos WHERE id = ?', (id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'erro': 'Produto não encontrado'}), 404
    
    cursor.execute('''
        UPDATE produtos SET 
            nome = ?, preco = ?, preco_antigo = ?, parcela = ?, 
            icone = ?, tag = ?, categoria = ?, destaque = ?, em_falta = ?
        WHERE id = ?
    ''', (
        dados['nome'],
        dados['preco'],
        dados.get('precoAntigo'),
        dados.get('parcela'),
        dados.get('icone', 'fa-bowl-food'),
        dados.get('tag', ''),
        dados.get('categoria', 'tradicional'),
        dados.get('destaque', 0),
        dados.get('em_falta', 0),
        id
    ))
    
    conn.commit()
    cursor.execute('SELECT * FROM produtos WHERE id = ?', (id,))
    produto = cursor.fetchone()
    conn.close()
    
    return jsonify({'mensagem': 'Produto atualizado com sucesso!', 'produto': serializar_produto(produto)})

@app.route('/api/produtos/<int:id>', methods=['DELETE'])
def deletar_produto(id):
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM produtos WHERE id = ?', (id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'erro': 'Produto não encontrado'}), 404
    
    cursor.execute('DELETE FROM produtos WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    
    return jsonify({'mensagem': 'Produto deletado com sucesso!'})

@app.route('/api/produtos/<int:id>', methods=['GET'])
def buscar_produto(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM produtos WHERE id = ?', (id,))
    produto = cursor.fetchone()
    conn.close()
    
    if produto:
        return jsonify(serializar_produto(produto))
    return jsonify({'erro': 'Produto não encontrado'}), 404

@app.route('/api/produtos/categoria/<categoria>', methods=['GET'])
def filtrar_por_categoria(categoria):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM produtos WHERE categoria = ? ORDER BY destaque DESC, id', (categoria,))
    produtos = cursor.fetchall()
    conn.close()
    return jsonify([serializar_produto(p) for p in produtos])

@app.route('/api/buscar', methods=['GET'])
def buscar_produtos():
    termo = request.args.get('q', '').lower()
    if not termo:
        return listar_produtos()
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM produtos 
        WHERE LOWER(nome) LIKE ? OR LOWER(tag) LIKE ? OR LOWER(categoria) LIKE ?
        ORDER BY destaque DESC, id
    ''', (f'%{termo}%', f'%{termo}%', f'%{termo}%'))
    produtos = cursor.fetchall()
    conn.close()
    return jsonify([serializar_produto(p) for p in produtos])

# ===== ROTAS DE COMPLEMENTOS =====

@app.route('/api/complementos', methods=['GET'])
def listar_complementos():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM complementos ORDER BY id')
    complementos = cursor.fetchall()
    conn.close()
    return jsonify([serializar_complemento(c) for c in complementos])

@app.route('/api/complementos', methods=['POST'])
def criar_complemento():
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    dados = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO complementos (nome, preco, icone, em_falta)
        VALUES (?, ?, ?, ?)
    ''', (dados['nome'], dados['preco'], dados.get('icone', 'fa-seedling'), dados.get('em_falta', 0)))
    
    conn.commit()
    comp_id = cursor.lastrowid
    cursor.execute('SELECT * FROM complementos WHERE id = ?', (comp_id,))
    comp = cursor.fetchone()
    conn.close()
    
    return jsonify({'mensagem': 'Complemento criado com sucesso!', 'complemento': serializar_complemento(comp)}), 201

@app.route('/api/complementos/<int:id>', methods=['PUT'])
def atualizar_complemento(id):
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    dados = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM complementos WHERE id = ?', (id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'erro': 'Complemento não encontrado'}), 404
    
    cursor.execute('''
        UPDATE complementos SET nome = ?, preco = ?, icone = ?, em_falta = ?
        WHERE id = ?
    ''', (dados['nome'], dados['preco'], dados.get('icone', 'fa-seedling'), dados.get('em_falta', 0), id))
    
    conn.commit()
    cursor.execute('SELECT * FROM complementos WHERE id = ?', (id,))
    comp = cursor.fetchone()
    conn.close()
    
    return jsonify({'mensagem': 'Complemento atualizado com sucesso!', 'complemento': serializar_complemento(comp)})

@app.route('/api/complementos/<int:id>', methods=['DELETE'])
def deletar_complemento(id):
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM complementos WHERE id = ?', (id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'erro': 'Complemento não encontrado'}), 404
    
    cursor.execute('DELETE FROM complementos WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    
    return jsonify({'mensagem': 'Complemento deletado com sucesso!'})

# ===== ROTAS DE COBERTURAS =====

@app.route('/api/coberturas', methods=['GET'])
def listar_coberturas():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM coberturas ORDER BY id')
    coberturas = cursor.fetchall()
    conn.close()
    return jsonify([serializar_cobertura(c) for c in coberturas])

@app.route('/api/coberturas', methods=['POST'])
def criar_cobertura():
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    dados = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO coberturas (nome, preco, icone, em_falta)
        VALUES (?, ?, ?, ?)
    ''', (dados['nome'], dados['preco'], dados.get('icone', 'fa-bottle-droplet'), dados.get('em_falta', 0)))
    
    conn.commit()
    cov_id = cursor.lastrowid
    cursor.execute('SELECT * FROM coberturas WHERE id = ?', (cov_id,))
    cov = cursor.fetchone()
    conn.close()
    
    return jsonify({'mensagem': 'Cobertura criada com sucesso!', 'cobertura': serializar_cobertura(cov)}), 201

@app.route('/api/coberturas/<int:id>', methods=['PUT'])
def atualizar_cobertura(id):
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    dados = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM coberturas WHERE id = ?', (id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'erro': 'Cobertura não encontrada'}), 404
    
    cursor.execute('''
        UPDATE coberturas SET nome = ?, preco = ?, icone = ?, em_falta = ?
        WHERE id = ?
    ''', (dados['nome'], dados['preco'], dados.get('icone', 'fa-bottle-droplet'), dados.get('em_falta', 0), id))
    
    conn.commit()
    cursor.execute('SELECT * FROM coberturas WHERE id = ?', (id,))
    cov = cursor.fetchone()
    conn.close()
    
    return jsonify({'mensagem': 'Cobertura atualizada com sucesso!', 'cobertura': serializar_cobertura(cov)})

@app.route('/api/coberturas/<int:id>', methods=['DELETE'])
def deletar_cobertura(id):
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM coberturas WHERE id = ?', (id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'erro': 'Cobertura não encontrada'}), 404
    
    cursor.execute('DELETE FROM coberturas WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    
    return jsonify({'mensagem': 'Cobertura deletada com sucesso!'})

# ===== ROTAS DE AVISOS =====

@app.route('/api/avisos', methods=['GET'])
def listar_avisos():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM avisos WHERE ativo = 1 ORDER BY id DESC')
    avisos = cursor.fetchall()
    conn.close()
    return jsonify([serializar_aviso(a) for a in avisos])

@app.route('/api/avisos/todos', methods=['GET'])
def listar_todos_avisos():
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM avisos ORDER BY id DESC')
    avisos = cursor.fetchall()
    conn.close()
    return jsonify([serializar_aviso(a) for a in avisos])

@app.route('/api/avisos', methods=['POST'])
def criar_aviso():
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    dados = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO avisos (mensagem, ativo, data_criacao)
        VALUES (?, ?, ?)
    ''', (dados['mensagem'], dados.get('ativo', 1), datetime.now().isoformat()))
    
    conn.commit()
    aviso_id = cursor.lastrowid
    cursor.execute('SELECT * FROM avisos WHERE id = ?', (aviso_id,))
    aviso = cursor.fetchone()
    conn.close()
    
    return jsonify({'mensagem': 'Aviso criado com sucesso!', 'aviso': serializar_aviso(aviso)}), 201

@app.route('/api/avisos/<int:id>', methods=['PUT'])
def atualizar_aviso(id):
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    dados = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM avisos WHERE id = ?', (id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'erro': 'Aviso não encontrado'}), 404
    
    cursor.execute('''
        UPDATE avisos SET mensagem = ?, ativo = ?
        WHERE id = ?
    ''', (dados['mensagem'], dados.get('ativo', 1), id))
    
    conn.commit()
    cursor.execute('SELECT * FROM avisos WHERE id = ?', (id,))
    aviso = cursor.fetchone()
    conn.close()
    
    return jsonify({'mensagem': 'Aviso atualizado com sucesso!', 'aviso': serializar_aviso(aviso)})

@app.route('/api/avisos/<int:id>', methods=['DELETE'])
def deletar_aviso(id):
    if not verificar_admin():
        return jsonify({'erro': 'Acesso negado'}), 403
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM avisos WHERE id = ?', (id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({'erro': 'Aviso não encontrado'}), 404
    
    cursor.execute('DELETE FROM avisos WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    
    return jsonify({'mensagem': 'Aviso deletado com sucesso!'})

# ===== ROTAS DE PEDIDOS =====

@app.route('/api/pedidos', methods=['POST'])
def criar_pedido():
    if 'usuario_id' not in session:
        return jsonify({'erro': 'Você precisa estar logado para fazer um pedido'}), 401
    
    dados = request.json
    
    if not dados or 'itens' not in dados or len(dados['itens']) == 0:
        return jsonify({'erro': 'Carrinho vazio'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM usuarios WHERE id = ?', (session['usuario_id'],))
    usuario = cursor.fetchone()
    if not usuario:
        conn.close()
        return jsonify({'erro': 'Usuário não encontrado'}), 404
    
    endereco = dados.get('endereco', usuario['endereco'])
    
    cursor.execute('''
        INSERT INTO pedidos (usuario_id, usuario_nome, usuario_telefone, itens, total, endereco, observacao, data, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        usuario['id'],
        usuario['nome'],
        usuario['telefone'],
        json.dumps(dados['itens']),
        dados.get('total', 0),
        endereco,
        dados.get('observacao', ''),
        datetime.now().isoformat(),
        'Recebido'
    ))
    
    conn.commit()
    pedido_id = cursor.lastrowid
    
    cursor.execute('SELECT * FROM pedidos WHERE id = ?', (pedido_id,))
    pedido = cursor.fetchone()
    conn.close()
    
    return jsonify({
        'mensagem': 'Pedido realizado com sucesso!',
        'pedido': serializar_pedido(pedido)
    }), 201

@app.route('/api/pedidos', methods=['GET'])
def listar_pedidos():
    if 'usuario_id' not in session:
        return jsonify({'erro': 'Você precisa estar logado'}), 401
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if verificar_admin():
        cursor.execute('SELECT * FROM pedidos ORDER BY id DESC')
    else:
        cursor.execute('SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY id DESC', (session['usuario_id'],))
    
    pedidos = cursor.fetchall()
    conn.close()
    return jsonify([serializar_pedido(p) for p in pedidos])

@app.route('/api/pedidos/<int:id>', methods=['GET'])
def buscar_pedido(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM pedidos WHERE id = ?', (id,))
    pedido = cursor.fetchone()
    conn.close()
    
    if not pedido:
        return jsonify({'erro': 'Pedido não encontrado'}), 404
    
    if 'usuario_id' in session and (pedido['usuario_id'] == session['usuario_id'] or verificar_admin()):
        return jsonify(serializar_pedido(pedido))
    
    return jsonify({'erro': 'Não autorizado'}), 401

# ===== ATUALIZAR STATUS DO PEDIDO (Admin e Usuário) =====
@app.route('/api/pedidos/<int:id>/status', methods=['PUT'])
def atualizar_status_pedido(id):
    """Atualiza o status de um pedido. Admin pode alterar qualquer status, usuário só pode cancelar."""
    if 'usuario_id' not in session:
        return jsonify({'erro': 'Você precisa estar logado'}), 401
    
    dados = request.json
    novo_status = dados.get('status')
    observacao = dados.get('observacao', '')
    
    status_validos = ['Recebido', 'Preparando', 'Saiu para entrega', 'Entregue', 'Cancelado']
    if novo_status not in status_validos:
        return jsonify({'erro': 'Status inválido'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM pedidos WHERE id = ?', (id,))
    pedido = cursor.fetchone()
    
    if not pedido:
        conn.close()
        return jsonify({'erro': 'Pedido não encontrado'}), 404
    
    is_admin = verificar_admin()
    is_owner = pedido['usuario_id'] == session['usuario_id']
    
    if not is_admin and not is_owner:
        conn.close()
        return jsonify({'erro': 'Não autorizado'}), 401
    
    # ===== REGRA: Admin não pode alterar pedidos cancelados pelo usuário =====
    if is_admin:
        if pedido['observacao'] and 'cancelado pelo usuário' in pedido['observacao'].lower():
            conn.close()
            return jsonify({
                'erro': 'Este pedido foi cancelado pelo usuário e não pode ser alterado pelo administrador.'
            }), 403
    
    # Usuário comum só pode cancelar pedidos
    if not is_admin:
        if pedido['status'] == 'Entregue':
            conn.close()
            return jsonify({'erro': 'Pedidos entregues não podem ser cancelados'}), 400
        if pedido['status'] == 'Cancelado':
            conn.close()
            return jsonify({'erro': 'Este pedido já foi cancelado'}), 400
        if novo_status != 'Cancelado':
            conn.close()
            return jsonify({'erro': 'Usuários só podem cancelar pedidos'}), 400
    
    # Atualizar observação se for cancelamento pelo usuário
    if not is_admin and novo_status == 'Cancelado':
        if observacao:
            observacao = f"{observacao} (cancelado pelo usuário)"
        else:
            observacao = "Pedido cancelado pelo usuário!"
    
    cursor.execute('''
        UPDATE pedidos SET status = ?, observacao = ? WHERE id = ?
    ''', (novo_status, observacao, id))
    conn.commit()
    
    cursor.execute('SELECT * FROM pedidos WHERE id = ?', (id,))
    pedido_atualizado = cursor.fetchone()
    conn.close()
    
    return jsonify({
        'mensagem': 'Status atualizado com sucesso!',
        'pedido': serializar_pedido(pedido_atualizado)
    })

# ===== ESTATÍSTICAS =====

@app.route('/api/estatisticas', methods=['GET'])
def estatisticas():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM usuarios')
    total_usuarios = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM produtos')
    total_produtos = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM pedidos')
    total_pedidos = cursor.fetchone()[0]
    
    cursor.execute('SELECT SUM(total) FROM pedidos')
    total_vendas = cursor.fetchone()[0] or 0
    
    cursor.execute('SELECT itens FROM pedidos')
    todos_pedidos = cursor.fetchall()
    conn.close()
    
    vendas_por_produto = {}
    for pedido in todos_pedidos:
        itens = json.loads(pedido['itens'])
        for item in itens:
            nome = item.get('nome', '')
            quantidade = item.get('quantidade', 0)
            if nome in vendas_por_produto:
                vendas_por_produto[nome] += quantidade
            else:
                vendas_por_produto[nome] = quantidade
    
    mais_vendidos = sorted(vendas_por_produto.items(), key=lambda x: x[1], reverse=True)[:5]
    
    return jsonify({
        'total_usuarios': total_usuarios,
        'total_produtos': total_produtos,
        'total_pedidos': total_pedidos,
        'total_vendas': total_vendas,
        'mais_vendidos': dict(mais_vendidos)
    })

if __name__ == '__main__':
    print("\n🚀 Servidor iniciado!")
    print("📋 Servidor rodando em: http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)