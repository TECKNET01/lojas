import sqlite3
from datetime import datetime

DB_NAME = 'acai_do_verao.db'

def get_db_connection():
    """Cria e retorna uma conexão com o banco de dados"""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_database():
    """Cria as tabelas se não existirem e insere dados padrão"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Tabela de usuários (com campo is_admin)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            telefone TEXT NOT NULL,
            endereco TEXT NOT NULL,
            senha TEXT NOT NULL,
            data_cadastro TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0
        )
    ''')
    
    # Tabela de produtos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            preco_antigo REAL,
            parcela TEXT,
            icone TEXT NOT NULL,
            tag TEXT,
            categoria TEXT NOT NULL,
            destaque INTEGER DEFAULT 0,
            em_falta INTEGER DEFAULT 0
        )
    ''')
    
    # Tabela de complementos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS complementos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            icone TEXT NOT NULL,
            em_falta INTEGER DEFAULT 0
        )
    ''')
    
    # Tabela de coberturas
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS coberturas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            icone TEXT NOT NULL,
            em_falta INTEGER DEFAULT 0
        )
    ''')
    
    # Tabela de avisos do sistema
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS avisos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mensagem TEXT NOT NULL,
            ativo INTEGER DEFAULT 1,
            data_criacao TEXT NOT NULL
        )
    ''')
    
    # Tabela de pedidos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            usuario_nome TEXT NOT NULL,
            usuario_telefone TEXT NOT NULL,
            itens TEXT NOT NULL,
            total REAL NOT NULL,
            endereco TEXT NOT NULL,
            observacao TEXT,
            data TEXT NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
        )
    ''')
    
    conn.commit()
    
    # ===== INSERIR DADOS PADRÃO =====
    
    # Verificar se já existe um administrador
    cursor.execute('SELECT COUNT(*) FROM usuarios WHERE is_admin = 1')
    admin_count = cursor.fetchone()[0]
    
    if admin_count == 0:
        # Criar administrador padrão
        import hashlib
        senha_hash = hashlib.sha256('admin123'.encode()).hexdigest()
        cursor.execute('''
            INSERT INTO usuarios (nome, email, telefone, endereco, senha, data_cadastro, is_admin)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            'Administrador',
            'admin@acaiverao.com',
            '(11) 99999-9999',
            'Rua Admin, 123 - São Paulo, SP',
            senha_hash,
            datetime.now().isoformat(),
            1
        ))
        print("✅ Administrador padrão criado! Email: admin@acaiverao.com / Senha: admin123")
    
    # Verificar se já existem produtos
    cursor.execute('SELECT COUNT(*) FROM produtos')
    count = cursor.fetchone()[0]
    
    if count == 0:
        produtos_padrao = [
            ('Açaí Tradicional', 18.90, 22.90, '2x R$ 9,45', 'fa-bowl-food', '+ granola', 'tradicional', 1, 0),
            ('Açaí com Banana', 21.90, 26.90, '2x R$ 10,95', 'fa-apple-whole', '+ mel', 'frutas', 1, 0),
            ('Creme de Açaí', 25.90, 29.90, '3x R$ 8,63', 'fa-blender-phone', 'vegano', 'cremes', 0, 0),
            ('Açaí Power', 29.90, 35.90, '3x R$ 9,96', 'fa-bolt', '+ whey', 'tradicional', 1, 0),
            ('Mix de Frutas', 24.90, 28.90, '2x R$ 12,45', 'fa-fruit', '+ leite cond.', 'frutas', 0, 0),
            ('Açaí Zero', 19.90, 24.90, '2x R$ 9,95', 'fa-cow', 'sem açúcar', 'zero', 0, 0),
            ('Açaí Nutella', 32.90, 38.90, '3x R$ 10,96', 'fa-chocolate', 'promoção', 'promo', 1, 0),
            ('Açaí com Morango', 23.90, 27.90, '2x R$ 11,95', 'fa-strawberry', 'frutas vermelhas', 'frutas', 0, 0)
        ]
        
        cursor.executemany('''
            INSERT INTO produtos (nome, preco, preco_antigo, parcela, icone, tag, categoria, destaque, em_falta)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', produtos_padrao)
        conn.commit()
    
    # Verificar se já existem complementos
    cursor.execute('SELECT COUNT(*) FROM complementos')
    comp_count = cursor.fetchone()[0]
    
    if comp_count == 0:
        complementos_padrao = [
            ('Granola', 2.00, 'fa-seedling', 0),
            ('Banana', 1.50, 'fa-apple-whole', 0),
            ('Morango', 2.50, 'fa-strawberry', 0),
            ('Kiwi', 2.00, 'fa-leaf', 0),
            ('Leite em Pó', 1.50, 'fa-cow', 0),
            ('Amendoim', 1.00, 'fa-peanut', 0),
            ('Coco Ralado', 1.50, 'fa-coconut', 0),
            ('Aveia', 1.00, 'fa-wheat-awn', 0)
        ]
        
        cursor.executemany('''
            INSERT INTO complementos (nome, preco, icone, em_falta)
            VALUES (?, ?, ?, ?)
        ''', complementos_padrao)
        conn.commit()
    
    # Verificar se já existem coberturas
    cursor.execute('SELECT COUNT(*) FROM coberturas')
    cov_count = cursor.fetchone()[0]
    
    if cov_count == 0:
        coberturas_padrao = [
            ('Leite Condensado', 2.00, 'fa-bottle-droplet', 0),
            ('Mel', 2.50, 'fa-jar', 0),
            ('Calda de Chocolate', 2.50, 'fa-chocolate', 0),
            ('Calda de Morango', 2.50, 'fa-strawberry', 0),
            ('Nutella', 3.00, 'fa-chocolate', 0),
            ('Doce de Leite', 2.00, 'fa-jar', 0)
        ]
        
        cursor.executemany('''
            INSERT INTO coberturas (nome, preco, icone, em_falta)
            VALUES (?, ?, ?, ?)
        ''', coberturas_padrao)
        conn.commit()
    
    conn.close()
    print("✅ Banco de dados inicializado com sucesso!")

def serializar_produto(produto):
    """Converte um produto do banco para dicionário"""
    return {
        'id': produto['id'],
        'nome': produto['nome'],
        'preco': produto['preco'],
        'precoAntigo': produto['preco_antigo'],
        'parcela': produto['parcela'],
        'icone': produto['icone'],
        'tag': produto['tag'],
        'categoria': produto['categoria'],
        'destaque': bool(produto['destaque']),
        'em_falta': bool(produto['em_falta'])
    }

def serializar_usuario(usuario):
    """Converte um usuário do banco para dicionário (sem senha)"""
    return {
        'id': usuario['id'],
        'nome': usuario['nome'],
        'email': usuario['email'],
        'telefone': usuario['telefone'],
        'endereco': usuario['endereco'],
        'data_cadastro': usuario['data_cadastro'],
        'is_admin': bool(usuario['is_admin'])
    }

def serializar_pedido(pedido):
    """Converte um pedido do banco para dicionário"""
    import json
    return {
        'id': pedido['id'],
        'usuario_id': pedido['usuario_id'],
        'usuario_nome': pedido['usuario_nome'],
        'usuario_telefone': pedido['usuario_telefone'],
        'itens': json.loads(pedido['itens']),
        'total': pedido['total'],
        'endereco': pedido['endereco'],
        'observacao': pedido['observacao'],
        'data': pedido['data'],
        'status': pedido['status']
    }

def serializar_complemento(comp):
    """Converte um complemento do banco para dicionário"""
    return {
        'id': comp['id'],
        'nome': comp['nome'],
        'preco': comp['preco'],
        'icone': comp['icone'],
        'em_falta': bool(comp['em_falta'])
    }

def serializar_cobertura(cov):
    """Converte uma cobertura do banco para dicionário"""
    return {
        'id': cov['id'],
        'nome': cov['nome'],
        'preco': cov['preco'],
        'icone': cov['icone'],
        'em_falta': bool(cov['em_falta'])
    }

def serializar_aviso(aviso):
    """Converte um aviso do banco para dicionário"""
    return {
        'id': aviso['id'],
        'mensagem': aviso['mensagem'],
        'ativo': bool(aviso['ativo']),
        'data_criacao': aviso['data_criacao']
    }